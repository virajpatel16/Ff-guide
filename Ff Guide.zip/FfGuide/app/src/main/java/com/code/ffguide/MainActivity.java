package com.code.ffguide;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    CardView card1,card2,card3,card4,card5,card6,card7,card8;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        card1=findViewById(R.id.Diamond);
        card2=findViewById(R.id.emotes);
        card3=findViewById(R.id.pets);
        card4=findViewById(R.id.calculate);
        card5=findViewById(R.id.map);
        card6=findViewById(R.id.guns);
        card7=findViewById(R.id.dress);
        card8=findViewById(R.id.refer);



        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "DailyDiamondFragment");
                startActivity(intent);
            }
        });

        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "EmotesFragment");
                startActivity(intent);
            }
        });

// Add onClickListeners for other cards similarly

        card3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "PetsFragment");
                startActivity(intent);
            }
        });
        card4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "CalculateFragment");
                startActivity(intent);
            }
        });
        card5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "MapFragment");
                startActivity(intent);
            }
        });
        card6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "GunsFragment");
                startActivity(intent);
            }
        });
        card7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "DressFragment");
                startActivity(intent);
            }
        });
        card8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, fragmrnt_container.class);
                intent.putExtra("fragment", "ReferFragment");
                startActivity(intent);
            }
        });
    }

    @SuppressLint("MissingSuperCall")
    public void onBackPressed() {
        // Show the exit screen
        Intent intent = new Intent(this, Exitapp.class);
        startActivity(intent);
        finish();
    }
}