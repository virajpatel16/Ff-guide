package com.code.ffguide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GunAdepter extends RecyclerView.Adapter<GunAdepter.Viewholder> {
    public GunAdepter(Context context, ArrayList<Gunmodel> gunlist) {
        this.context = context;
        this.gunlist = gunlist;
    }

    public Context context;

    ArrayList<Gunmodel> gunlist;

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.gunmodel, parent, false);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        Gunmodel gunmodel = gunlist.get(position);
        holder.gunname.setText(gunmodel.gunname);
        holder.gunimage.setImageResource(gunmodel.gunimage);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataToOtherActivities(gunmodel.gundatails, gunmodel.gunimage);

            }
        });
    }

    @Override
    public int getItemCount() {
        return gunlist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView gunname;
        ImageView gunimage;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            gunname = itemView.findViewById(R.id.rv_gun_name);
            gunimage = itemView.findViewById(R.id.rv_gun_image);
        }
    }

    private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context, gundetail.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);

        context.startActivity(intent1);


    }
}
