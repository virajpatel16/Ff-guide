package com.code.ffguide;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class SharedViewModel extends ViewModel {
    private MutableLiveData<List<Integer>> imageData = new MutableLiveData<>();

    public LiveData<List<Integer>> getImageData() {
        return imageData;
    }

    public void setImageData(List<Integer> images) {
        imageData.setValue(images);
    }
}
