package com.code.ffguide;

public class petmodel {

    public petmodel(int petimage, String petname, String petdatail) {
        this.petimage = petimage;
        this.petname = petname;
        this.petdatail = String.valueOf(petdatail);
    }

    public int petimage;

    public String petname;
    public String petdatail;

}
