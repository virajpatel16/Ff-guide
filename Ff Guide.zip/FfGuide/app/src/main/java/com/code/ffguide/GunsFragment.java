package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class GunsFragment extends Fragment {

RecyclerView recyclerView;

ArrayList<Gunmodel>gunlist=new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=  inflater.inflate(R.layout.fragment_guns, container, false);

        gunlist.add(new Gunmodel(R.drawable.mp40,"Golden MP40",getContext().getString(R.string.an94)));

        gunlist.add(new Gunmodel(R.drawable.titanscar,"Titan sacar",getContext().getString(R.string.titanscar)));

        gunlist.add(new Gunmodel(R.drawable.winterland,"Winterland Mi014",getContext().getString(R.string.mi014)));
        gunlist.add(new Gunmodel(R.drawable.moonfamus,"Moon Famus",getContext().getString(R.string.moonfamus)));

        gunlist.add(new Gunmodel(R.drawable.a94,"A94",getContext().getString(R.string.an94)));
        gunlist.add(new Gunmodel(R.drawable.m14,"M14",getContext().getString(R.string.m14)));
        gunlist.add(new Gunmodel(R.drawable.ak47,"Ak47",getContext().getString(R.string.ak47)));
        gunlist.add(new Gunmodel(R.drawable.scar,"Scar",getContext().getString(R.string.scar)));
        gunlist.add(new Gunmodel(R.drawable.groza,"Groza",getContext().getString(R.string.groza)));
        gunlist.add(new Gunmodel(R.drawable.famas,"Famas",getContext().getString(R.string.moonfamus)));

        recyclerView=view.findViewById(R.id.rv_gun);
// Create StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 1,GridLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);


        GunAdepter adapter = new GunAdepter(getActivity(),gunlist);
        recyclerView.setAdapter(adapter);
   
    return view;
    }
}