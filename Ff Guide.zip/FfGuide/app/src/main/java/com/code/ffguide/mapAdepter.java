package com.code.ffguide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class mapAdepter extends RecyclerView.Adapter<mapAdepter.Viewholder> {
    public mapAdepter(Context context, ArrayList<mapmodel> maplist) {
        this.context = context;
        this.maplist = maplist;
    }

    public Context context;
    ArrayList<mapmodel> maplist;

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.mapreclerview, parent, false);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        mapmodel mapmodel = maplist.get(position);
        holder.mapname.setText(mapmodel.mapname);
        holder.mapimage.setImageResource(mapmodel.mapimage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataToOtherActivities(mapmodel.mapdetail, mapmodel.mapimage);

            }
        });
    }

    @Override
    public int getItemCount() {
        return maplist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {


        TextView mapname;
        CircleImageView mapimage;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            mapimage = itemView.findViewById(R.id.rv_map_image);
            mapname = itemView.findViewById(R.id.rv_map_name);
        }
    }

    private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context, datilsdata.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);
        context.startActivity(intent1);


        // Add more intents for other activities as needed
    }
}
