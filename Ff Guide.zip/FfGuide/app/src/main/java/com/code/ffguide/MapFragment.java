package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class MapFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<mapmodel> maplist = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_map, container, false);


        maplist.add(new mapmodel(R.drawable.santa, "Santa Catarina", getContext().getString(R.string.santa)));

        maplist.add(new mapmodel(R.drawable.boyfront, "Boyfront", getContext().getString(R.string.boyfront)));

        maplist.add(new mapmodel(R.drawable.council, "council Hall", getContext().getString(R.string.council)));
        maplist.add(new mapmodel(R.drawable.hampton, "Hampton", getContext().getString(R.string.hampiton)));


        recyclerView = view.findViewById(R.id.rv_map);
// Create StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);


        mapAdepter adapter = new mapAdepter(getActivity(), maplist);
        recyclerView.setAdapter(adapter);
        return view;

    }

}