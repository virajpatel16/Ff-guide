package com.code.ffguide;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Slape_Screen extends AppCompatActivity {
    private static final long SPLASH_DELAY = 2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slape_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // If internet is available, proceed to main activity after SPLASH_TIME_OUT milliseconds
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start MainActivity after a delay
                startMainActivity();
            }
        }, 2000); // 2000 milliseconds = 2 seconds


    }

    private void startMainActivity() {
        Intent intent = new Intent(this, Privacy_police.class);
        startActivity(intent);
        finish(); // Finish the splash screen activity to prevent going back to it when pressing back button
    }
}