package com.code.ffguide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DressAdepter extends RecyclerView.Adapter<DressAdepter.Vieholder> {
    public DressAdepter(Context context, ArrayList<dressmodel> dresslist) {
        this.context = context;
        this.dresslist = dresslist;
    }

    public Context context;
    ArrayList<dressmodel> dresslist;

    @NonNull
    @Override
    public Vieholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dressmodel, parent, false);

        return new Vieholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Vieholder holder, int position) {

        dressmodel dressmodel = dresslist.get(position);
        holder.dressname.setText(dressmodel.dressname);
        holder.dressimage.setImageResource(dressmodel.dressimage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataToOtherActivities(dressmodel.dressdetail, dressmodel.dressimage);

            }
        });
    }

    @Override
    public int getItemCount() {
        return dresslist.size();
    }

    public class Vieholder extends RecyclerView.ViewHolder {
        TextView dressname;
        ImageView dressimage;

        public Vieholder(@NonNull View itemView) {
            super(itemView);

            dressname = itemView.findViewById(R.id.rv_dress_name);
            dressimage = itemView.findViewById(R.id.rv_dress_image);
        }
    }
    private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context,datilsdata.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);


        context.startActivity(intent1);


        // Add more intents for other activities as needed
    }
}
