package com.code.ffguide;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class fragmrnt_container extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fragmrnt_container);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve the extra from the intent
        String fragmentName = getIntent().getStringExtra("fragment");

        // Open the appropriate fragment
        if (fragmentName != null) {
            Fragment fragment;
            switch (fragmentName) {
                case "DailyDiamondFragment":
                    fragment = new DailyDimondFragment();
                    break;
                case "EmotesFragment":
                    fragment = new EmotesFragment();
                    break;
                case "PetsFragment":
                    fragment = new PetsFragment();
                    break;
                case "CalculateFragment":
                    fragment = new CalculateFragment();
                    break;
                case "MapFragment":
                    fragment = new MapFragment();
                    break;
                case "GunsFragment":
                    fragment = new GunsFragment();
                    break;
                case "DressFragment":
                    fragment = new DressFragment();
                    break;
                case "ReferFragment":
                    fragment = new ReferFragment();
                    break;
                default:
                    fragment = new DailyDimondFragment();
            }

            // Begin the fragment transaction
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame, fragment)
                    .commit();
        }
    }

}


