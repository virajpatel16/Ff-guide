package com.code.ffguide;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class CarsFragment extends Fragment {
    RecyclerView recycler;
    public ArrayList<carsmodel> carlist =new ArrayList<>() ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_cars, container, false);

        carlist.add(new carsmodel(R.drawable.sportcars,"SportCar",getContext().getString(R.string.sportcars)));

        carlist.add(new carsmodel(R.drawable.motor,"Motor Car",getContext().getString(R.string.monster)));

        carlist.add(new carsmodel(R.drawable.motorcycle,"Motor Cycle",getContext().getString(R.string.motorcycle)));
        carlist.add(new carsmodel(R.drawable.amphibian,"Amphibian",getContext().getString(R.string.amphib)));

        carlist.add(new carsmodel(R.drawable.militryjeep,"Militry Jeep",getContext().getString(R.string.militryjeep)));
        carlist.add(new carsmodel(R.drawable.tuktuk,"Tuk-Tuk",getContext().getString(R.string.tuktuk)));

        carlist.add(new carsmodel(R.drawable.van,"Van",getContext().getString(R.string.van)));

        recycler=view.findViewById(R.id.rv_data);
// Create StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 3,GridLayoutManager.VERTICAL,false);
        recycler.setLayoutManager(layoutManager);


        carAdepter adapter = new carAdepter(getActivity(),carlist);
        recycler.setAdapter(adapter);


        return  view;
    }
}