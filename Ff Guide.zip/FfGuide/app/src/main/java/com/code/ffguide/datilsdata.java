package com.code.ffguide;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

public class datilsdata extends AppCompatActivity implements DiamondGuideListener {

    TextView datanew;
    ImageView newimage;
    Button active;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_datilsdata);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        datanew = findViewById(R.id.data);
        newimage = findViewById(R.id.newimage);
        active = findViewById(R.id.active);
        DiamondGuideListener listener = this;
        if (listener != null) {
            listener.onDataReceived(getIntent().getStringExtra("data"), getIntent().getIntExtra("image", 0));
        }
        active.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }


    @Override
    public void onDataReceived(String data, int image) {

        datanew.setText(data);
        newimage.setImageResource(image);


    }

    private void openDialog() {
        // Create a new instance of the dialog
        Dialog dialog = new Dialog(this);

        // Set the custom dialog layout
        dialog.setContentView(R.layout.dialog_custom_second);


        ExtendedFloatingActionButton buttonConform = dialog.findViewById(R.id.buttonconform);

        // Set a click listener for the button
        buttonConform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform any action when the button is clicked
                // For example, you can dismiss the dialog
                dialog.dismiss();
                finish();

                // You can also perform any other action here
                // For example, start another activity or show a toast
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // Show the dialog
        dialog.show();
    }
}