package com.code.ffguide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PetsAdepter extends RecyclerView.Adapter<PetsAdepter.Viewholder> {

    public PetsAdepter(Context context, ArrayList<petmodel> petlist) {
        this.context = context;
        this.petlist = petlist;
    }

    public Context context;
    public ArrayList<petmodel> petlist;

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.petreclereview, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        petmodel petmodel = petlist.get(position);
        holder.petname.setText(petmodel.petname);
        holder.petimage.setImageResource(petmodel.petimage);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataToOtherActivities(petmodel.petdatail, petmodel.petimage);

            }
        });
    }

    @Override
    public int getItemCount() {
        return petlist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView petname;
        ImageView petimage;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            petname = itemView.findViewById(R.id.rv_pet_name);
            petimage = itemView.findViewById(R.id.rv_pet_image);
        }
    }

    private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context, datilsdata.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);
        context.startActivity(intent1);


        // Add more intents for other activities as needed
    }

}
