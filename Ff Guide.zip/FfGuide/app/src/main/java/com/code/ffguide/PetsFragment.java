package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class PetsFragment extends Fragment {


    RecyclerView recyclerView;

    ArrayList<petmodel> petlist = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pets, container, false);


        petlist.add(new petmodel(R.drawable.derki, "FF Derki",getContext().getString(R.string.derki) ));

        petlist.add(new petmodel(R.drawable.yeti, "FF Yeti", getContext().getString(R.string.yati)));

        petlist.add(new petmodel(R.drawable.moony, "FF Moony", getContext().getString(R.string.moony)));
        petlist.add(new petmodel(R.drawable.ottero, "FF Ottero", getContext().getString(R.string.petdetail)));

        petlist.add(new petmodel(R.drawable.pandas, "FF Pandas", getContext().getString(R.string.pandas)));
        petlist.add(new petmodel(R.drawable.robo, "FF Robo", getContext().getString(R.string.robo)));

        petlist.add(new petmodel(R.drawable.flash, "FF Flash", getContext().getString(R.string.flash)));
        petlist.add(new petmodel(R.drawable.shiba, "FF Shiba", getContext().getString(R.string.shiba)));

        recyclerView = view.findViewById(R.id.rv_pets);

        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);


        PetsAdepter adapter = new PetsAdepter(getActivity(), petlist);
        recyclerView.setAdapter(adapter);


        return view;
    }
}