package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CharatersFragment extends Fragment {

    RecyclerView recycler;
    public ArrayList<imageModel> imageList = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_charaters, container, false);

        imageList.add(new imageModel(R.drawable.hayato, "Hayat", getContext().getString(R.string.hayat)));

        imageList.add(new imageModel(R.drawable.moco, "moco", getContext().getString(R.string.moco)));

        imageList.add(new imageModel(R.drawable.wukong, "wukong", getContext().getString(R.string.wunkong)));
        imageList.add(new imageModel(R.drawable.antonio, "antonio", getContext().getString(R.string.antonio)));

        imageList.add(new imageModel(R.drawable.andrew, "andrew", getContext().getString(R.string.andrew)));
        imageList.add(new imageModel(R.drawable.kelly, "Kelly", getContext().getString(R.string.kelly)));

        imageList.add(new imageModel(R.drawable.olivia, "Olivia", getContext().getString(R.string.olivia)));
        imageList.add(new imageModel(R.drawable.ford, "Ford", getContext().getString(R.string.ford)));

        imageList.add(new imageModel(R.drawable.nikita, "Nikita", getContext().getString(R.string.n)));
        imageList.add(new imageModel(R.drawable.misha, "Misha", getContext().getString(R.string.misha)));

        imageList.add(new imageModel(R.drawable.paloma, "Paloma", getContext().getString(R.string.paloma)));

        imageList.add(new imageModel(R.drawable.miguel, "Miguel", getContext().getString(R.string.miguel)));
        imageList.add(new imageModel(R.drawable.caroline, "Caroline", getContext().getString(R.string.caroline)));
        imageList.add(new imageModel(R.drawable.maxim, "Maxim", getContext().getString(R.string.maxim)));


        recycler = view.findViewById(R.id.recycler);

        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        recycler.setLayoutManager(layoutManager);


        ChareterAdepter adapter = new ChareterAdepter(getActivity(), imageList);
        recycler.setAdapter(adapter);

        return view;
    }
}