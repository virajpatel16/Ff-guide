package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class gundetail extends AppCompatActivity  implements DiamondGuideListener {

    TextView datanew;
    ImageView newimage;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gundetail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        datanew = findViewById(R.id.gundata);
        newimage = findViewById(R.id.gunimage);
        DiamondGuideListener listener = this;
        if (listener != null) {
            listener.onDataReceived(getIntent().getStringExtra("data"), getIntent().getIntExtra("image", 0));
        }
    }

    @Override
    public void onDataReceived(String data, int image) {
        datanew.setText(data);
        newimage.setImageResource(image);
    }
}