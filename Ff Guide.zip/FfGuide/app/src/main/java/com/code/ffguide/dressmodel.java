package com.code.ffguide;

public class dressmodel {


    public int dressimage;

    public String dressname;

    public dressmodel(int dressimage, String dressname, String dressdetail) {
        this.dressimage = dressimage;
        this.dressname = dressname;
        this.dressdetail = dressdetail;
    }

    public String dressdetail;


}
