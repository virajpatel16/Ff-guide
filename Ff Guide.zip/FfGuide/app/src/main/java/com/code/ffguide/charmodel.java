package com.code.ffguide;

public class charmodel {



}
