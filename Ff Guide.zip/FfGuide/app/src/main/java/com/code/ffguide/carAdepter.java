package com.code.ffguide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class carAdepter extends RecyclerView.Adapter<carAdepter.Viewholder> {


    public Context context;
    public ArrayList<carsmodel> carlist;

    public carAdepter(Context context, ArrayList<carsmodel> carlist) {
        this.context = context;
        this.carlist = carlist;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.carrecylervie, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, @SuppressLint("RecyclerView") int position) {
        carsmodel carsmodel = carlist.get(position);
        holder.carname.setText(carsmodel.name);
        holder.carimage.setImageResource(carsmodel.image);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendDataToOtherActivities(carsmodel.detailschareter, carsmodel.image);

            }
        });

    }

    @Override
    public int getItemCount() {
        return carlist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView carname;
        ImageView carimage;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            carname = itemView.findViewById(R.id.rv_car_name);
            carimage = itemView.findViewById(R.id.rv_car_image);
        }
    }

    private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context, gundetail.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);

        context.startActivity(intent1);


    }


}