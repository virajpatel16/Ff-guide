package com.code.ffguide;

public interface DiamondGuideListener {
    void onDataReceived(String data,int image);


}
