package com.code.ffguide;

public class mapmodel {

    public mapmodel(int mapimage, String mapname,String mapdetail) {
        this.mapimage = mapimage;
        this.mapname = mapname;
        this.mapdetail= mapdetail;
    }

    public int mapimage;
    public String mapname;

    public String mapdetail;





}
