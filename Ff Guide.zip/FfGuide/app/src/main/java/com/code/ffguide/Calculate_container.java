package com.code.ffguide;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class Calculate_container extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculate_container);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String fragmentName = getIntent().getStringExtra("fragmentload");

        // Open the appropriate fragment
        if (fragmentName != null) {
            Fragment fragment;
            switch (fragmentName) {
                case "basicfragment":
                    fragment = new BasicFragment();
                    break;
                case "normalFragment":
                    fragment = new NormalFragment();
                    break;
                case "advanceFragment":
                    fragment = new AdvanceFragment();
                    break;
                case "CharatersFragment":
                    fragment = new CharatersFragment();
                    break;
                case "CarsFragment":
                    fragment = new CarsFragment();
                    break;
                case "DailydimondFragment":
                    fragment = new Daily_dimond_Fragment();
                    break;
                case "TipsFragment":
                    fragment = new TipsFragment();
                    break;


                default:
                    fragment = new BasicFragment();
            }

            // Begin the fragment transaction
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.calculateframe, fragment)
                    .commit();
        }


    }
}