package com.code.ffguide;

public class Gunmodel {



    public Gunmodel(int gunimage, String gunname, String gundatails) {
        this.gunimage = gunimage;
        this.gundatails = gundatails;
        this.gunname = gunname;

    }

    public int gunimage;
    public String gundatails;
    public String gunname;



}
