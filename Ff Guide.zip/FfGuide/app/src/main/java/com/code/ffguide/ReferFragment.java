package com.code.ffguide;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class ReferFragment extends Fragment {


Button buttonSubmit;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_refer, container, false);

        buttonSubmit=view.findViewById(R.id.buttonSubmit);


        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });


  return  view;
    }
   public  void share (){
        // App name
        String appName = getContext().getString(R.string.app_name);
        // Play Store link of your app
        String appLink = "https://play.google.com/store/apps/details?id=" + getContext().getPackageName();

        // Create the share message
        String shareMessage = "Check out " + appName + " on Google Play Store:\n" + appLink;

        // Create a sharing intent
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this app!");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);

        // Start the chooser to share the app
        Intent chooserIntent = Intent.createChooser(shareIntent, "Share " + appName + " via");

        // Check if there are apps available to handle the share intent
        if (shareIntent.resolveActivity(getContext().getPackageManager()) != null) {
            getContext().startActivity(chooserIntent);
        } else {
            // If no app can handle the share intent, display a toast
            Toast.makeText(getContext(), "No app found to handle the share action", Toast.LENGTH_SHORT).show();
        }
    }

}