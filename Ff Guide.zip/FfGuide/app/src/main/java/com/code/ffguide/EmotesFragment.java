package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class EmotesFragment extends Fragment {

    RecyclerView recycler;
    public ArrayList<emotesmodel> emotelist =new ArrayList<>() ;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_emotes, container, false);

        emotelist.add(new emotesmodel(R.drawable.takeover,"Takeover"));

        emotelist.add(new emotesmodel(R.drawable.makeite,"Make it rain"));

        emotelist.add(new emotesmodel(R.drawable.pushup,"Pushup"));
        emotelist.add(new emotesmodel(R.drawable.footbal,"Pro footbal"));

        emotelist.add(new emotesmodel(R.drawable.bhangra,"Bhangra"));
        emotelist.add(new emotesmodel(R.drawable.threaten,"Threaten"));
        emotelist.add(new emotesmodel(R.drawable.provoke,"Provoke"));
        emotelist.add(new emotesmodel(R.drawable.ffwcthrone,"FFWC Throne"));
        emotelist.add(new emotesmodel(R.drawable.babyshark,"Baby Shark"));
        emotelist.add(new emotesmodel(R.drawable.celebration,"Celebrate"));

        recycler=view.findViewById(R.id.rv_emote);
// Create StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2,GridLayoutManager.VERTICAL,false);
        recycler.setLayoutManager(layoutManager);


        EmotesAdepter adapter = new EmotesAdepter(getActivity(),emotelist);
        recycler.setAdapter(adapter);
    return view;
    }
}