package com.code.ffguide;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class DailyDimondFragment extends Fragment {


    LinearLayout liner1,liner2,liner3,liner4;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_daily_dimond, container, false);
        liner1=view.findViewById(R.id.chareter);
        liner2=view.findViewById(R.id.cars);
        liner3=view.findViewById(R.id.dimond);
        liner4=view.findViewById(R.id.tips);



        liner1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireActivity(), Calculate_container.class);
                intent.putExtra("fragmentload", "CharatersFragment");
                startActivity(intent);
            }
        });

        liner2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireActivity(), Calculate_container.class);
                intent.putExtra("fragmentload", "CarsFragment");
                startActivity(intent);
            }
        });

        liner3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireActivity(), Calculate_container.class);
                intent.putExtra("fragmentload", "DailydimondFragment");
                startActivity(intent);
            }
        });

        liner4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireActivity(), Calculate_container.class);
                intent.putExtra("fragmentload", "TipsFragment");
                startActivity(intent);
            }
        });

        return view;
    }
}