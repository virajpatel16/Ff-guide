package com.code.ffguide;

public class carsmodel {


    public carsmodel(int image, String name, String detailschareter) {
        this.image = image;
        this.name = name;
        this.detailschareter = detailschareter;
    }

    public int image;
    public  String name;
    public  String detailschareter;




}
