package com.code.ffguide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ChareterAdepter extends RecyclerView.Adapter<ChareterAdepter.Viewholder> {
    public Context context;
    public ArrayList<imageModel> imageList;

    public ChareterAdepter(Context context, ArrayList<imageModel> imageList) {
        this.context = context;
        this.imageList = imageList;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recylerivew, parent, false);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, @SuppressLint("RecyclerView") int position) {
        imageModel imageModel = imageList.get(position);
        holder.textView.setText(imageModel.details);
        holder.imageView.setImageResource(imageModel.image);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendDataToOtherActivities(imageModel.detailschareter, imageModel.image);

            }
        });

    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView imageView;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.txt_rv_tittle);
            imageView = itemView.findViewById(R.id.img_rv_image);


        }
    }private void sendDataToOtherActivities(String data, int image) {
        // Create an Intent to start other activities
        Intent intent1 = new Intent(context, gundetail.class);
        intent1.putExtra("data", data);
        intent1.putExtra("image", image);

        context.startActivity(intent1);


    }
}
