package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class BasicFragment extends Fragment {

    private EditText edBasicCalsiNum;
    private ImageView imgCalculator;
    private TextView txtDollar;
    private Button btnCount;


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_basic, container, false);
        edBasicCalsiNum = view.findViewById(R.id.ed_basic_calsi_num);
        txtDollar = view.findViewById(R.id.tat_dollar);
        btnCount = view.findViewById(R.id.basicbtn_count);
        imgCalculator = view.findViewById(R.id.img_calculator);

        imgCalculator.setImageResource(R.drawable.calculate);
        initView();
   return view;
    }

    private void initView() {



        btnCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


// Inside onCreateView() or onViewCreated() method of your fragment
                edBasicCalsiNum = getView().findViewById(R.id.ed_basic_calsi_num);

// Check if edBasicCalsiNum is not null before proceeding with further operations
                if (edBasicCalsiNum != null) {
                    String enteredNumberString = edBasicCalsiNum.getText().toString();

                    // Input validation (optional): check if entered text is a number
                    if (enteredNumberString.isEmpty()) {
                        Toast.makeText(getActivity(), "Please enter a number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    float enteredNumber;
                    try {
                        enteredNumber = Float.parseFloat(enteredNumberString);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getActivity(), "Invalid number format", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    float result = enteredNumber * 35;
                    txtDollar.setText(result + "Dollars");
                } else {
                    // Handle the case where edBasicCalsiNum is null
                }

            }
        });


    }
}