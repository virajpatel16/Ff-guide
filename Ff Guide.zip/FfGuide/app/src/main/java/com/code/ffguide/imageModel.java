package com.code.ffguide;

public class imageModel {
    public imageModel(int image, String details, String detailschareter) {
        this.image = image;
        this.details = details;
        this.detailschareter = detailschareter;
    }

    public int image;
    public  String details;
    public  String detailschareter;


}
