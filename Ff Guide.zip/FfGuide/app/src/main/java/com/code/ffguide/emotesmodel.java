package com.code.ffguide;

public class emotesmodel {



    public  int emoteimage;

    public String emotename;

    public emotesmodel(int emoteimage, String emotename) {
        this.emoteimage = emoteimage;
        this.emotename = emotename;
    }
}
