package com.code.ffguide;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class DressFragment extends Fragment {

RecyclerView recyclerView;
ArrayList<dressmodel> dresslist= new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_dress, container, false);


        dresslist.add(new dressmodel(R.drawable.season1,"Season1",getContext().getString(R.string.moonfamus)));

        dresslist.add(new dressmodel(R.drawable.season2,"Season2",getContext().getString(R.string.moonfamus)));

        dresslist.add(new dressmodel(R.drawable.season3,"Season3",getContext().getString(R.string.moonfamus)));
        dresslist.add(new dressmodel(R.drawable.season4,"Season4",getContext().getString(R.string.moonfamus)));

        dresslist.add(new dressmodel(R.drawable.season5,"Season5",getContext().getString(R.string.moonfamus)));
        dresslist.add(new dressmodel(R.drawable.season6,"Season6",getContext().getString(R.string.moonfamus)));


        recyclerView=view.findViewById(R.id.rv_dress);
// Create StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2,GridLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);


        DressAdepter adapter = new DressAdepter(getActivity(),dresslist);
        recyclerView.setAdapter(adapter);
        
    return  view;
    
    }
}